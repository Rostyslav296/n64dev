Place the files inside `/filesystem/` at the root of your SD card.

This example will load images from the SD card if it can mount the SD, or from the ROM otherwise (so that it works on emulators and real hardware).